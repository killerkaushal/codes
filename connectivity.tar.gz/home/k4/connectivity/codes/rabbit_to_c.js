var amqp = require('amqplib/callback_api');
let { response } = require('./send_response');
let { sendtorabbit } = require('./send_udp_to_rabbit');
var port = 5575;
var host = '127.0.0.1';
var udp = require('dgram');

amqp.connect('amqp://k4user:truring@127.0.0.1', function (err, conn) {
  conn.createChannel(function (err, ch) {
    var q = 'request_queue';
    ch.assertQueue(q, { durable: true });
    ch.prefetch(1);
    console.log(" [*] Waiting for messages in %s. To exit press CTRL+C", q);
    ch.consume(q, function (msg) {
      console.log(" [x] Received %s", msg.content.toString());
      var client = udp.createSocket('udp4');
      var data1 = msg.content.toString();
      console.log('data= ', data1);
      var data = new Buffer(data1);
      client.send(data, 0, data.length, port, host);
      ch.ack(msg);
    }, { noAck: false });
  });
});

response();
sendtorabbit();
