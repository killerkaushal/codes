#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#define maxlen 5000
struct Map 					//table containing data fo users
{
	char* key;
	char* val;
};
struct Node 				// node of a linked list
{
	struct Map *data;
	struct Node *next;
};
char * substring(char * string , int start, int end) 		//
{
	char *sub;
	int length=end-start;
	sub=(char *)malloc(length+1);
	int i=0,k=start;
	while(k<end)
	{
		sub[i++]=string[k++];
	}
	sub[i]='\0';
	return sub;

}
void push(struct Node** head_ref, struct Map* m) 	//Adding in a linked List
{ 
    // Allocate memory for node 
    struct Node* new_node = (struct Node*)malloc(sizeof(struct Node));
    if((*head_ref)==NULL)
    {
    	new_node->next=NULL;
    	new_node->data=m;
    	(*head_ref)=new_node;
    }
    else
    {
    	new_node->data=m;
    	new_node->next=(*head_ref);
    	(*head_ref)=new_node;
    }
} 
struct Map* makekey_val_pair(char * string , int length) 		//Maping value with key
{
	int pos=0;
	for(int i=0;i<length;++i)
	{
		if(string[i]==':')
			{
				pos=i;
				break;
			}
	}
	int start=0;
	char * key=substring(string,0+1,pos-1);
	char * val=substring(string,pos+2,length-1);
	struct Map* m=(struct Map *)malloc(sizeof(struct Map));
	m->key=key;
	m->val=val;
	return m;

}
void printList(struct Node* head)   		//
{
	struct Node *temp=(head);
	while(temp!=NULL)
	{
		printf("%s : %s\n",temp->data->key,temp->data->val);
		temp=temp->next;
	}
}
char* find_key_value_pair(struct Node* head,char * key)		//searching key 
{
	while(head!=NULL)
	{
		if(strcmp(head->data->key,key)==0)
		{
			return head->data->val;
		}
		head=head->next;
	}
	return NULL;
}
struct Node * read_json (char * buffer  , int buffer_len) 		//Reading json string of user(object)
{
	struct Node * head=NULL;	
	
	for(int i=0;i<buffer_len;++i)
		{
			if (buffer[i]=='\n')
			{	buffer_len=i;
				break;
			}
		}
	int arr[maxlen],k=0;
	for(int i=0;i<buffer_len;++i)
	{
		if(buffer[i]=='{' || buffer[i]=='}'|| buffer[i]==',')
		{
			arr[k++]=i;
		}
	}
	for(int i=0;i<k-1;++i)
	{
		char *sub= substring(buffer,arr[i]+1,arr[i+1]);
		struct Map* m = makekey_val_pair(sub,arr[i+1]-arr[i]-1);
		push(&head,m);
	}
	
	return head;
}
