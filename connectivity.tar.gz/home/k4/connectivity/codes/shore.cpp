#include <map>
#include <stack>
#include <string>
#include <iostream>
#include <cstdio>
#include "json.h"
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 
#include <vector>
#include <sstream>
using namespace std;
class user {
public:
	unsigned int mark,n_devices; 
	string	dl_rate;
	enum {
		e_normal = 0,
		e_released
	}	state;
};

static map<string, user *> M;
static stack<user *> S;
string convert_int_to_string(unsigned int num)
{
	ostringstream oss;
	oss.str("");
	oss.clear();
	oss<<num;
	return oss.str();
}
string convert_char_to_string(char * buffer)
{
	string str="";
	for(int i=0;i<strlen(buffer);++i)
	{
		str=str+buffer[i];
	}
//	str=str+"\0";

	return str;
}
vector<string> convert_string_to_vector_deliminator_space(string buffer)
{
	vector<string> temp;
	std::istringstream iss(buffer);
	// getting a vector from space separated string 
	for(string buffer;iss>>buffer;)
	{
		temp.push_back(buffer);

	}
	for(int i=0;i<temp.size();++i)
	{
		cout<<temp[i]<<"\n";
	}
	return temp;

}
void s_add_user( unsigned int mark, string dl_rate )
{
	string user_mark=convert_int_to_string(mark);
	string send="sh /home/k4/connectivity/scripts-ratelimit/USER-ADD-MARK-DOWN "+user_mark+" "+dl_rate;
	const char * command =send.c_str();
	system(command);
	cout<<user_mark<<" "<<dl_rate<<"\n";	
}
void s_del_user( unsigned int mark, string dl_rate )
{
	string user_mark=convert_int_to_string(mark);
	string send="sh /home/k4/connectivity/scripts-ratelimit/USER-DEL-MARK-DOWN "+user_mark+" "+dl_rate;
	const char * command =send.c_str();
	system(command);
	 cout<<user_mark<<" "<<dl_rate<<"\n";
}
void s_assign_device( unsigned int mark, string mac, string ip )
{
	string user_mark=convert_int_to_string(mark);
	cout<<"user mark "<<user_mark<<"\n";
	string send="sh /home/k4/connectivity/scripts-ratelimit/DEVICE-ASSIGN-DOWN "+user_mark+" "+mac+" "+ip;
	const char * command =send.c_str();
	system(command);
	 cout<<user_mark<<" "<<mac<<" "<<ip<<"\n";
}
void s_release_device( unsigned int mark, string mac, string ip )
{
	string user_mark=convert_int_to_string(mark);
	string send="sh /home/k4/connectivity/scripts-ratelimit/DEVICE-DEL-DOWN "+user_mark+" "+mac+" "+ip;
	const char * command =send.c_str();
	system(command);
	 cout<<user_mark<<" "<<mac<<" "<<ip<<"\n";
}
void	d_add_user( string user_name, string dl_rate )
{
	user	*U;

	if ( M.find(user_name) != M.end() ) {
		cout << user_name << " exists\n";
		return;
	}

	if( S.empty() ) {
		cout << user_name << " out of resources\n";
		return;
	}

	U = S.top();
	S.pop();

	//s_add_user( U->mark, dl_rate );
	U->state = user::e_normal;
	U->n_devices = 0;
//	U->dl_rate=dl_rate;
	M[user_name] = U;
}

void 	d_mod_user_rate(string user_name,string dl_rate)
{
	if(M.find(user_name)==M.end())
	{
			cout<<user_name<<" does not exist\n";
			return ;
	}
	M[user_name]->dl_rate=dl_rate;

	//s_del_user( M[user_name]->mark, M[user_name]->dl_rate );
	//s_add_user( M[user_name]->mark, dl_rate );
}
void	d_del_user( string user_name )
{
	if ( M.find(user_name) == M.end() ) {
		cout << user_name << " does not exist\n";
		return;
	} 

	M[user_name]->state = user::e_released;

	if( M[user_name]->n_devices == 0 ) {
		user	*U = M[user_name];

	//	s_del_user( U->mark, U->dl_rate );

		M.erase(user_name);
		S.push(U);
	}

}

void	a_assign_device( string user_name, string mac, string ip )
{
	if ( M.find(user_name) == M.end() ) {
		cout << user_name << " does not exist\n";
		return;
	}
//	s_assign_device( M[user_name]->mark, mac, ip );

	M[user_name]->n_devices++;
	cout<<M[user_name]->n_devices<<"\n";
}

void	a_release_device( string user_name, string mac, string ip )
{
	if ( M.find(user_name) == M.end() ) {
		cout << user_name << " does not exist\n";
		return;
	} 

//	s_release_device( M[user_name]->mark, mac, ip );

	M[user_name]->n_devices--;

	if( (M[user_name]->n_devices == 0) && (M[user_name]->state == user::e_released) ) {
		user	*U = M[user_name];

		//s_del_user( U->mark ,U->dl_rate );

		M.erase(user_name);
		S.push(U);
	}

}
void	create_pool(unsigned int N)
{
	unsigned int i;
	
	for ( i=0; i<N; i++ ) {
		user	*U = new user;

		U->mark = i + 1;
		S.push(U);
	}
}
void decision(char * buffer )
{
	string str=convert_char_to_string(buffer);
        vector<string> v;
        std::istringstream iss(str);
        // getting a vector from space separated string
        for(string str;iss>>str;)
        {
                v.push_back(str);

        }
        for(int i=0;i<v.size();++i)
        {
                cout<<v[i]<<"\n";
        }
        if(v[0]=="opcode")
	{
		string opcode=v[1];
		string username=v[3];
		if(opcode=="C")
		{
			string dl_rate=v[5];
			d_add_user(username,dl_rate);
		}
		else if(opcode=="U")
		{
			string dl_rate=v[5];
			d_mod_user_rate(username,dl_rate);

		}
		else if(opcode=="D")
		{
			d_del_user(username);
		}
	}
	else if(v[0]=="assign")
	{
		string username=v[1];
		string mac=v[5];
		string ip=v[3];
		a_assign_device(username,mac,ip);
	}
	else if(v[0]=="release")
	{
		string username=v[1];
		string ip=v[3];
		string mac=v[5];
		a_release_device(username,mac,ip);
	}




}
#define MAX 5000
int main()
{
	create_pool(100);
	string add_port="sh /home/k4/connectivity/scripts-ratelimit/addport.sh ";
	const char * command=add_port.c_str();
//	system(command);
	int sockfd,connfd;
	socklen_t len;
	struct sockaddr_in servaddr,cliaddr;
	sockfd=socket(AF_INET,SOCK_STREAM,0);
	if(sockfd==-1)
	{
		perror("Socket creation failed\n");
		exit(1);
	}
	else
		cout<<"Socket succesfully created\n";
	bzero(&servaddr,sizeof(servaddr));
	servaddr.sin_family=AF_INET;
	servaddr.sin_addr.s_addr=inet_addr("127.0.01");
	servaddr.sin_port=htons(5557);
	if((bind(sockfd,(struct sockaddr*)&servaddr,sizeof(servaddr)))!=0)
	{
		cout<<"Socket bind failed...\n";
		exit(1);
	}
	else
		cout<<"Socket successfully bindeed ..\n";
	if((listen(sockfd,5))!=0)
	{
		cout<<"Listen failed..\n";
		exit(1);
	}
	else
		cout<<"Server is listening\n";
	len=sizeof(cliaddr);
	connfd=accept(sockfd,(struct sockaddr*)&cliaddr,&len);
	if(connfd<0)
	{
		cout<<"server accept failded\n";
		exit(1);
	}
	else 
		cout<<"Server accept the client ...\n";
	char buffer[MAX];
	while(1)
	{
		cout<<"hi i m up\n";
		bzero(buffer,sizeof(buffer));
		read(connfd,buffer,sizeof(buffer));
	       	cout<<buffer<<"\n";
		decision(buffer);
	}
	close(sockfd);


	return 0;
}
