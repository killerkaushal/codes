sendtorabbit = () => {
	var PORT = 5576;
	var HOST = '127.0.0.1';
	var amqp = require('amqplib/callback_api');
	var dgram = require('dgram');
	var server = dgram.createSocket('udp4');

	server.on('listening', function () {
		var address = server.address();
		console.log('UDP Server listening on ' + address.address + ":" + address.port);
	});

	server.on('message', function (message, remote) {
		// console.log(remote.address + ':' + remote.port +' - ' + message);
		console.log((message.toString().split("\n"))[0]);
		console.log(typeof (message.toString()))
		var data1 = '{';
		if ((message.toString().search("<")) != -1) {
			
			var m1=message.toString().split('<');
			var m2=m1[0].split(' ');
			var m3=m1[1].split('>');
			var i=0;
	
			for(i=0;i<4;i=i+2)
			{
				data1=data1+'\"'+m2[i]+'\":\"'+m2[i+1]+"\",";
			}
			data1=data1+'\"'+m2[4]+'\":\"'+m3[0]+'\"}';
		}
		else {
			var m1 = (message.toString().split('\n')[0]).split(' ');
			var i = 0;
			console.log('going to make json\n');
			for (i = 0; i < m1.length; i = i + 2) {
				data1 = data1 + '\"' + m1[i] + '\":\"' + m1[i + 1] + '\"';
				if (i == m1.length - 2) {
					data1 = data1 + '}';
				}
				else {
					data1 = data1 + ',';
				}

			}
		}
			amqp.connect('amqp://k4user:truring@127.0.0.1', function (err, conn) {
				conn.createChannel(function (err, ch) {
					var q = 'device';
					var msg = data1;
					ch.assertQueue(q, { durable: true });
					ch.sendToQueue(q, Buffer.from(msg));
					console.log(" [x] Sent %s", msg);
				});
				setTimeout(function () { conn.close(); }, 50000);
			});
		


	});

	server.bind(PORT, HOST);
}

module.exports = { sendtorabbit }	
