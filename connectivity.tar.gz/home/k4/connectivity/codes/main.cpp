#include <map>
#include <stack>
#include <string>
#include <iostream>
#include <cstdio>
#include "json.h"
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 
#include <vector>
#include <sstream>
using namespace std;
class user {
public:
	unsigned int mark,n_devices; 
	string	dl_rate , ul_rate;
	enum {
		e_normal = 0,
		e_released
	}	state;
};

static map<string, user *> M;
static stack<user *> S;
string convert_int_to_string(unsigned int num)
{
	ostringstream oss;
	oss.str("");
	oss.clear();
	oss<<num;
	return oss.str();
}
string convert_char_to_string(char * buffer)
{
	string str="";
	for(int i=0;i<strlen(buffer);++i)
	{
		str=str+buffer[i];
	}
//	str=str+"\0";
	return str;
}
vector<string> convert_string_to_vector_deliminator_space(string buffer)
{
	vector<string> temp;
	std::istringstream iss(buffer);
	// getting a vector from space separated string 
	for(string buffer;iss>>buffer;)
	{
		temp.push_back(buffer);

	}
	for(int i=0;i<temp.size();++i)
	{
		cout<<temp[i]<<"\n";
	}
	return temp;

}
/*
void send_to_shore(const char *buff, int portno)
{
	cout<<"Message sent to shore programm\n\t"<<buff<<"\n";
	int sockfd,connfd;
	struct sockaddr_in servaddr,cliaddr;
	sockfd=socket(AF_INET,SOCK_STREAM,0);
	if(sockfd==-1)
	{
		cout<<"Socket creation failed ... \n";
		exit(1);
	}
	else 
		cout<<"Socket created successfully\n";
	bzero(&servaddr,sizeof(servaddr));
	// assign IP , PORT
	servaddr.sin_family=AF_INET;
	servaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
	servaddr.sin_port=htons(portno);
	if(connect(sockfd,(struct sockaddr*)&servaddr,sizeof(servaddr))!=0)
	{
		cout<<"connection with shore server failed...\n";
	       exit(1);
	}
	else 
		cout<<"connected with server \n";
	write(sockfd,buff,strlen(buff));
	close(sockfd);

		
}*/
void send_to_rabbit(char * buff,int portno)
{	
	cout << "Message sent to divyanshu \n\t "<<buff<<"\n";
	int sockfd;  
   	struct sockaddr_in     servaddr; 
  
    // Creating socket file descriptor 
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) { 
        perror("socket creation failed"); 
        exit(EXIT_FAILURE); 
    } 
  
    memset(&servaddr, 0, sizeof(servaddr)); 
      
    // Filling server information 
   servaddr.sin_family = AF_INET; 
    servaddr.sin_port = htons(portno); 
    servaddr.sin_addr.s_addr = INADDR_ANY; 
   // printf("client is up of c\n");
    int n, len; 
   	sendto(sockfd , (const char *)buff, strlen(buff), 
        MSG_CONFIRM, (const struct sockaddr *) &servaddr,  
            sizeof(servaddr));
           
    close(sockfd); 
}
void send_to_avjit(const char * buff, int portno)
{
		cout<< "Message sent to avijt :\n \t"<<buff<<"\n";

		int sockfd; 
    	struct sockaddr_in     servaddr; 
 		// Creating socket file descriptor 
    	if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) { 
    	    perror("socket creation failed"); 
            exit(EXIT_FAILURE); 
    	} 
  
       	memset(&servaddr, 0, sizeof(servaddr)); 
      
     	//Filling server information 
        servaddr.sin_family = AF_INET; 
        servaddr.sin_port = htons(portno); 
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
       
   	 	int n;
    	socklen_t len; 
   	
   		sendto(sockfd, (const char *)buff, strlen(buff), 
        	MSG_CONFIRM, (const struct sockaddr *) &servaddr,  
        	   sizeof(servaddr));
   		close(sockfd);
}
void a_add_user( string user_name, string password )
{
	string send="subscriber add "+user_name+" password "+password;
	const char * buffer=send.c_str();
	send_to_avjit(buffer,5555);
	//free(buff);
}
void a_del_user(string user_name)
{
	string send="subscriber del "+user_name;
	const char * buffer=send.c_str();
	send_to_avjit(buffer,5555);
	//free(buff);	
}
void a_mod_user(string user_name, string password)
{
	string send="subscriber mod "+user_name+" password "+password;
	const char * buffer=send.c_str();
	send_to_avjit(buffer,5555);
	//free(buff);
}
void a_add_blacklist_user(string mac)
{
	string send="blacklist add "+mac+"\0";
	const char * buffer =send.c_str();
	send_to_avjit(buffer,5555);
	//free(buff);
}
void a_del_blacklist_user(string mac)
{
	string send="blacklist del "+mac+"\0";
	const char * buffer =send.c_str();
	send_to_avjit(buffer,5555);
	//free(buff);
}
void s_add_user( unsigned int mark, string ul_rate,string dl_rate )
{
	string user_mark=convert_int_to_string(mark);
	string send="sh /home/k4/connectivity/scripts-ratelimit/USER-ADD-MARK_UP "+user_mark+" "+ul_rate+" "+dl_rate;
	const char * command =send.c_str();
	system(command);
//	cout<<user_mark<<" "<<ul_rate<<"\n";	
}
void s_del_user( unsigned int mark, string  ul_rate, string dl_rate) 
{
	string user_mark=convert_int_to_string(mark);
	string send="sh /home/k4/connectivity/scripts-ratelimit/USER-DEL-MARK_UP "+user_mark+" "+ul_rate+" "+dl_rate;
	const char * command =send.c_str();
	system(command);
//	 cout<<user_mark<<" "<<ul_rate<<"\n";
}
void s_assign_device( unsigned int mark, string mac, string ip )
{
	string user_mark=convert_int_to_string(mark);
	cout<<"user mark "<<user_mark<<"\n";
	string send="sh /home/k4/connectivity/scripts-ratelimit/DEVICE-ASSIGN_UP "+user_mark+" "+mac+" "+ip;
	const char * command =send.c_str();
	system(command);
//	 cout<<user_mark<<" "<<mac<<" "<<ip<<"\n";
}
void s_release_device( unsigned int mark, string mac, string ip )
{
	string user_mark=convert_int_to_string(mark);
	string send="sh /home/k4/connectivity/scripts-ratelimit/DEVICE-DEL_UP "+user_mark+" "+mac+" "+ip;
	const char * command =send.c_str();
	system(command);
//	 cout<<user_mark<<" "<<mac<<" "<<ip<<"\n";
}
void	d_add_user( string user_name, string password, string ul_rate , string dl_rate)
{
	user	*U;

	if ( M.find(user_name) != M.end() ) {
		cout << user_name << " exists\n";
		return;
	}

	if( S.empty() ) {
		cout << user_name << " out of resources\n";
		return;
	}

	U = S.top();
	S.pop();

	s_add_user( U->mark, ul_rate,dl_rate);
	a_add_user( user_name, password );

	U->state = user::e_normal;
	U->n_devices = 0;

	M[user_name] = U;
}

void 	d_mod_user_rate(string user_name,string ul_rate,string dl_rate)
{
	if(M.find(user_name)==M.end())
	{
			cout<<user_name<<" does not exist\n";
			return ;
	}
	M[user_name]->ul_rate=ul_rate;

	s_del_user( M[user_name]->mark, M[user_name]->ul_rate ,M[user_name]->dl_rate);
	s_add_user( M[user_name]->mark, ul_rate,dl_rate );
}
void	d_mod_user( string user_name, string password, string ul_rate,string dl_rate)
{
	if ( M.find(user_name) == M.end() ) {
		cout << user_name << " does not exist\n";
		return;
	} 

	s_del_user( M[user_name]->mark, M[user_name]->ul_rate,M[user_name]->dl_rate );
	s_add_user( M[user_name]->mark, ul_rate,dl_rate);
	a_mod_user( user_name, password );

	M[user_name]->ul_rate = ul_rate;
	M[user_name]->dl_rate=dl_rate;
}

void	d_del_user( string user_name )
{
	if ( M.find(user_name) == M.end() ) {
		cout << user_name << " does not exist\n";
		return;
	} 

	a_del_user( user_name );

	M[user_name]->state = user::e_released;

	if( M[user_name]->n_devices == 0 ) {
		user	*U = M[user_name];

		s_del_user( U->mark, U->ul_rate,U->dl_rate );

		M.erase(user_name);
		S.push(U);
	}

}

void	a_assign_device( string user_name, string mac, string ip )
{
	if ( M.find(user_name) == M.end() ) {
		cout << user_name << " does not exist\n";
		return;
	}
	s_assign_device( M[user_name]->mark, mac, ip );

	M[user_name]->n_devices++;
	cout<<M[user_name]->n_devices<<"\n";
}

void	a_release_device( string user_name, string mac, string ip )
{
	if ( M.find(user_name) == M.end() ) {
		cout << user_name << " does not exist\n";
		return;
	} 

	s_release_device( M[user_name]->mark, mac, ip );

	M[user_name]->n_devices--;

	if( (M[user_name]->n_devices == 0) && (M[user_name]->state == user::e_released) ) {
		user	*U = M[user_name];

		s_del_user( U->mark, U->ul_rate,U->dl_rate );

		M.erase(user_name);
		S.push(U);
	}

}
/*
void make_string_for_shore(struct Node * head)
{
	string send="";
	string opcode=convert_char_to_string(find_key_value_pair(head,"opcode"));
	string username=convert_char_to_string(find_key_value_pair(head,"username"));
	string dl_rate=convert_char_to_string(find_key_value_pair(head,"downlink"));
	send=send+"opcode "+opcode+" username "+username+" downlink "+dl_rate+"\0";
	cout<<send<<"\n";
	const char * buff=send.c_str();
	send_to_shore(buff,5557);

}*/
void	create_pool(unsigned int N)
{
	unsigned int i;
	
	for ( i=0; i<N; i++ ) {
		user	*U = new user;

		U->mark = i + 1;
		S.push(U);
	}
}
void decision_1(struct Node * head)
{
	string opcode = convert_char_to_string(find_key_value_pair(head,"opcode"));
	cout<<opcode<<"\n";
	if(opcode=="C")
	{
		string username=convert_char_to_string(find_key_value_pair(head,"username"));
		string password=convert_char_to_string(find_key_value_pair(head,"password"));
		string dl_rate=convert_char_to_string(find_key_value_pair(head,"downlink"));
		string ul_rate=convert_char_to_string(find_key_value_pair(head,"uplink"));
		d_add_user(username,password,ul_rate,dl_rate);
	}
	else if(opcode=="D")
	{
		string username=convert_char_to_string(find_key_value_pair(head,"username"));
		d_del_user(username);		
	}
	else if(opcode=="U")
	{
		string username=convert_char_to_string(find_key_value_pair(head,"username"));
		string ul_rate=convert_char_to_string(find_key_value_pair(head,"uplink"));
		string dl_rate=convert_char_to_string(find_key_value_pair(head,"downlink"));
		d_mod_user_rate(username,ul_rate,dl_rate);
	}
	else if(opcode=="P")
	{
		string username=convert_char_to_string(find_key_value_pair(head,"username"));
		string ul_rate=convert_char_to_string(find_key_value_pair(head,"uplink"));
		string password=convert_char_to_string(find_key_value_pair(head,"password"));
		string dl_rate=convert_char_to_string(find_key_value_pair(head,"downlink"));
		d_mod_user(username,password,ul_rate,dl_rate);
	}
	else if (opcode=="B")
	 { 	
	 	string username=convert_char_to_string(find_key_value_pair(head,"username"));
		string mac=convert_char_to_string(find_key_value_pair(head,"mac"));
		a_add_blacklist_user(mac);

	 }
	else if (opcode == "W")
	{
		string username=convert_char_to_string(find_key_value_pair(head,"username"));
		string mac=convert_char_to_string(find_key_value_pair(head,"mac"));
		a_del_blacklist_user(mac);

	}

}
void decision_2(char * buffer)
{
//	cout<<buffer<<"\n";
	string s = convert_char_to_string(buffer);
	cout<<s<<"\n";
	vector<string> v;
	istringstream iss(s);
	for(string s;iss>>(s);)
	{
		v.push_back(s);
	}
	
	string username=v[1];
	string ip=v[3];
	string mac=v[5];;
	cout<<"printing vector \n";
	for(int i=0;i<v.size();++i)
	{
		cout<<v[i]<<"\n";
	}
//	cout<<"\n";
	if(v[0]=="assign")
	{
		a_assign_device(username,mac,ip);
	}
	else if(v[0]=="release")
	{
		a_release_device(username,mac,ip);	
	}


}
#define MAX 5000
int main()
{
	create_pool(100);
	string add_port="sh /home/k4/connectivity/scripts-ratelimit/addport.sh ";
	const char * command=add_port.c_str();
	system(command);
	int udpfd1,udpfd2,nready,maxfpd;
	char buffer[MAX];
	pid_t childpid;
	fd_set rset;
	ssize_t n;
	socklen_t len;
	const int on =1;
	struct sockaddr_in cliaddr, servaddr;
	void sig_chld(int);
	bzero(&servaddr,sizeof(servaddr));
	servaddr.sin_family=AF_INET;
	servaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
	// opening socket for connection between rabbit_mq and  connectivity programm
	servaddr.sin_port=htons(5575);
	udpfd1=socket(AF_INET,SOCK_DGRAM,0);
	int t =bind(udpfd1,(struct sockaddr*)&servaddr,sizeof(servaddr));
	if(t<0)
	{
		perror("Error in binding socket 1");
		exit(1);
	}
	// opening socket for connection between radius & dhcp server and connectivity programm
	servaddr.sin_port=htons(5556);
	udpfd2=socket(AF_INET ,SOCK_DGRAM,0);
	t=bind(udpfd2,(struct sockaddr*)&servaddr,sizeof(servaddr));
	if(t<0)
	{
		perror("Error in binding socket 2");
		exit(1);
	}

	// receiving message of startup from radius and dhcp server 
//	n=recvfrom(udpfd2,buffer,sizeof(buffer),0,(struct sockaddr*)&cliaddr,&len);
	char * hello="hello";
	send_to_rabbit(hello,5577);
	cout<<"hello sent\n";
	bzero(buffer,sizeof(buffer));
	FD_ZERO(&rset);
	maxfpd=max(udpfd1,udpfd2)+1;
	FD_SET(udpfd1,&rset);
	FD_SET(udpfd2,&rset);
	while(1)
	{
		FD_SET(udpfd1,&rset);
		FD_SET(udpfd2,&rset);
		nready=select(maxfpd,&rset,NULL,NULL,NULL);
		bzero(buffer,sizeof(buffer));
		if(FD_ISSET(udpfd1,&rset))
		{
			bzero(buffer,sizeof(buffer));
			n=recvfrom(udpfd1,buffer,sizeof(buffer),0,(struct sockaddr*)&cliaddr,&len);
			struct Node * head=read_json(buffer,strlen(buffer));
			printList(head);
			decision_1(head);
		//	make_string_for_shore(head);
		}
		if(FD_ISSET(udpfd2,&rset))
		{
			bzero(buffer,sizeof(buffer));
			n=recvfrom(udpfd2,buffer,sizeof(buffer),0,(struct sockaddr*)&cliaddr,&len);
			// sending ans to website portal 
			send_to_rabbit(buffer,5576);
			decision_2(buffer);
		//	send_to_shore(buffer,5557);

		}
	}
	return 0;
}
