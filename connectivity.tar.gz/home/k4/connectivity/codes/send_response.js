let response = () => {
	var PORT = 5577;
	var HOST = '127.0.0.1';

	var dgram = require('dgram');
	var server = dgram.createSocket('udp4');
	server.on('listening', function () {
		var address = server.address();
		console.log('UDP Server listening on ' + address.address + ":" + address.port);
	});

	server.on('message', function (message, remote) {
		// console.log(remote.address + ':' + remote.port +' - ' + message);
		console.log((message.toString().split("\n"))[0]);
		console.log(typeof (message.toString()))
		var amqp = require('amqplib/callback_api');
		amqp.connect('amqp://k4user:truring@127.0.0.1', function (err, conn) {
			conn.createChannel(function (err, ch) {
				var q = 'hello_queue';
				var msg = message.toString().split("\n")[0];
				ch.assertQueue(q, { durable: true });
				ch.sendToQueue(q, Buffer.from(msg));
				console.log(" [x] Sent %s", msg);
			});
			setTimeout(function () { conn.close(); }, 50000);
		});
	}


	);
	server.bind(PORT, HOST);
}

module.exports = {response};
